// Constantes
const monScore = document.getElementById('monScore');
const boxBalle = document.getElementById('boxBalle');
const cursor = document.getElementById("cursor");
const levelMenu = document.getElementById("levelMenu");
const levelButtons = document.querySelectorAll(".levelButton");
const countDown = new Audio("audio/arcade-countdown-7007.mp3");
const soundUrls = [
    "audio/click1.mp3",
    "audio/click2.mp3",
    "audio/click3.mp3",
    "audio/click4.mp3"
];
const ballSizes = {
    easy: 160,
    medium: 110,
    hard: 70
};
const totalImages = 5;
const totalSound = 4;
let soundIndex = 0;
let score = 0;
let currentImageIndex = 1;
let timer;
let timeRemaining = 60;

const preloadedSounds = soundUrls.map(url => {
    const audio = new Audio(url);
    audio.load();
    return audio;
});

// Initialisation du menu et du curseur
document.addEventListener("DOMContentLoaded", () => {
    document.body.classList.add("menu-active");
    cursor.style.display = "none"; // masquer le curseur
    document.getElementById("particleContainer").style.display = "none"; // cache les particules
});

// Menu de niveau
levelButtons.forEach(button => {
    button.addEventListener("click", (e) => {
        const selectedLevel = e.target.dataset.level;
        startGame(selectedLevel);
    });
});

// Fonction pour démarrer le jeu
function startGame(level) {
    levelMenu.style.display = "none";
    document.body.classList.remove("menu-active");
    cursor.style.display = "block";

    const ballSize = ballSizes[level] || 160;
    boxBalle.style.width = `${ballSize}px`;
    boxBalle.style.height = `${ballSize}px`;

    startCountdown(() => {
        document.getElementById("monScore").style.display = "block";
        document.getElementById("monTimer").style.display = "block";
        document.getElementById("boxBalle").style.display = "block";
        document.getElementById("particleContainer").style.display = "block"; // Afficher les particules

        moveBoxBalle(); // Position initiale
        changeCircleImage(); // Première image
        startTimer(); // Démarrer le chronomètre
    });
}

// Fonction de compte à rebours
function startCountdown(callback) {
    const countdown = document.getElementById("levelCountdown");
    if (!countdown) {
        console.error("Element #levelCountdown introuvable !");
        return;
    }

    countDown.play();
    countdown.classList.remove("hidden");

    let countdownValue = 3;
    countdown.textContent = countdownValue;

    const interval = setInterval(() => {
        countdownValue--;
        countdown.textContent = countdownValue > 0 ? countdownValue : '';
        if (countdownValue <= 0) {
            clearInterval(interval);
            countdown.classList.add("hidden");
            callback();
        }
    }, 1000);
}

// Fonction pour démarrer le chronomètre
function startTimer() {
    const timerDisplay = document.getElementById("monTimer");

    timer = setInterval(() => {
        timeRemaining--;
        timerDisplay.textContent = `Temps restant : ${timeRemaining}`;

        if (timeRemaining <= 0) {
            clearInterval(timer);
            endGame();
        }
    }, 1000);
}

// Fonction de fin de jeu
function endGame() {
    document.getElementById("monScore").style.display = "none";
    document.getElementById("monTimer").style.display = "none";
    document.getElementById("boxBalle").style.display = "none";

    const endScreen = document.createElement("div");
    endScreen.id = "endScreen";
    endScreen.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
        background-color: rgba(0, 0, 0, 0.8); color: white; display: flex;
        flex-direction: column; align-items: center; justify-content: center;
        font-family: var(--font); cursor: none;`;

    endScreen.innerHTML = `
        <h1>Temps écoulé !</h1>
        <p>Votre score : ${score}</p>
        <button id="returnToMenu">Retour au menu</button>
        <style>#returnToMenu{cursor:none;}</style>`;

    document.body.appendChild(endScreen);

    document.getElementById("returnToMenu").addEventListener("click", () => {
        document.body.removeChild(endScreen);
        showMenu();
    });
}

// Fonction pour revenir au menu
function showMenu() {
    window.location.reload();
}

// Curseur personnalisé
document.body.addEventListener("mousemove", function (e) {
    cursor.style.left = (e.clientX + 5) + "px";
    cursor.style.top = (e.clientY + 5) + "px";
    createParticle(e.clientX, e.clientY); // Générer des particules
});

// Fonction pour créer des particules
function createParticle(x, y) {
    const particle = document.createElement("div");
    particle.className = "particle";
    particle.style.left = `${x}px`;
    particle.style.top = `${y}px`;
    document.getElementById("particleContainer").appendChild(particle);

    setTimeout(() => {
        particle.remove();
    }, 1000);
}

// Fonction pour déplacer la balle
function moveBoxBalle() {
    const size = parseInt(getComputedStyle(boxBalle).width, 10);
    const randomX = Math.random() * (window.innerWidth - size - 100);
    const randomY = Math.random() * (window.innerHeight - size - 100);
    
    boxBalle.style.left = `${randomX}px`;
    boxBalle.style.top = `${randomY}px`;
}

// Fonction pour changer l'image de la balle
function changeCircleImage() {
    boxBalle.style.backgroundImage = `url('img/${currentImageIndex}.png')`;
    currentImageIndex = (currentImageIndex % totalImages) + 1;
}

// Événement clic sur la balle
boxBalle.addEventListener("click", () => {
    score++;
    const sound_Url = soundUrls[soundIndex];
    if (sound_Url) {
        const audio = new Audio(sound_Url);
        audio.play().catch(err => console.error(`Erreur lors de la lecture du son : ${err.message}`));
    }
    soundIndex = (soundIndex + 1) % totalSound;
    monScore.textContent = `Score : ${score}`;

    moveBoxBalle();
    changeCircleImage();
});