<div align="center">

![borne_arcade_v1.png](design/borne_arcade_v1.png)

</div> 

# Projet mini jeux NSI
NSI 1ère Projet Mini Jeux

## Liens utiles
- Gestion des tâches : [projet Github](https://github.com/users/camarm-dev/projects/6)

## Livrable
Cette version ne contient que une encienne version de osu.html dont le code a été comenté legerement modifier pour une meilleur comprenssion.
Pour acceder a la version actuelle veuillez vous rendre sur le site [NSI-POJET]()

## Crédits sons

Les sons sont des sons libres de droits du site pixabay; liens des sites:
- https://pixabay.com/sound-effects/success-02-68338/
- https://pixabay.com/sound-effects/arcade-countdown-7007/
- https://pixabay.com/fr/sound-effects/retro-video-game-coin-pickup-38299/
- https://pixabay.com/fr/sound-effects/8-bit-game-sfx-sound-21-269970/
- https://pixabay.com/fr/sound-effects/8-bit-powerup-6768/

